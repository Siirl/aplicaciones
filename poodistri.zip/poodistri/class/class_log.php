<?php
session_start();
include('class.php');
class Login{
    public function validar($user,$pass){
        //validar si el usuario existe o no
            $sql1="select * from usuarios where usuario='$user' and password='$pass'";
            $res1=mysqli_query(Conectar::conec(),$sql1);
             if($row1=mysqli_fetch_array($res1)){
                //se crea la variable de SESION
                $_SESSION['usuario']=$row1['usuario'];
                echo "
                <script type='text/javascript'>
                 Swal.fire({
                 icon : 'success',
                title : 'BIENVENIDO',
                 text :  ' $_SESSION[usuario] al Sistema'
                }).then((result) => {
                     if(result.isConfirmed){
                     window.location='./menua.php';
                    }
                }); </script>";
             }else{
                $_SESSION['usuario']=NULL;
                echo "
                <script type='text/javascript'>
                 Swal.fire({
                 icon : 'error',
                title : 'ERROR!!',
                 text :  ' el usuario $user o password  no son correctos'
                }).then((result) => {
                     if(result.isConfirmed){
                     window.location='./index.php';
                    }
                }); </script>";

             }

        
    }
}
?>